import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter_map/flutter_map.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:latlong2/latlong.dart' as latLng;
class FavouritesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text('Favourites'),
          centerTitle: true,
          backgroundColor: Colors.red,
        ),
        body: Container(
          child: Column(
            children: [
              const SizedBox(height: 15 , width: 20),
              buildSearchField(),
              buildMap()

            ],
          ),
        ),
      );
  Widget buildSearchField() {
    // final color = Colors.white;

    return TextField(
      style: TextStyle(color: Colors.purple),
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        hintText: 'Search',
        hintStyle: TextStyle(color: Colors.black),
        prefixIcon: Icon(Icons.search, color: Colors.brown),
        filled: true,
        fillColor: Colors.white12,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: Colors.purpleAccent.withOpacity(0.7)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide(color: Colors.blue.withOpacity(0.7)),
        ),
      ),
    );
  }
 Widget buildMap(){
    return Column(
      children: [
        Expanded(child: GoogleMap(
          mapType: MapType.normal,
          initialCameraPosition: CameraPosition(
            target: LatLng(9.1450 , 40.4897),

            zoom: 18
          ),
          onMapCreated: (GoogleMapController controller){
            
          },
        ),),
      ],
    );
 }

}
